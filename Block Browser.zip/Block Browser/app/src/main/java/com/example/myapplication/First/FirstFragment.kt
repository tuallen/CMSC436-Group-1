package com.example.myapplication.First

import android.app.PendingIntent.getActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider


class FirstFragment: Fragment(com.example.myapplication.R.layout.first_fragment_layout){


    }


